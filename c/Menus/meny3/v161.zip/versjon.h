#define VER     "v1.61"
#define VER_NUM 0x0161
#define DATO    "27/11/94"
