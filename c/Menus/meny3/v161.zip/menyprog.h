#define  NAVN "MENY III"
#include "versjon.h"


#define ANTVALG 14



typedef struct {
    char id [11];          /* M� v�re "MENY III  " */
    char menynavn [13];    /* Navn p� n�v�rende menyfil */
    int  feilkode;         /* Feil som skal vises av programmet */
    int  menyvalg;         /* N�v�rende menyvalg */
    unsigned char progdsk; /* Disken �nsket program er p� */
    char progdir [51];     /* Directory for �nsket program (med \) */
    unsigned char len;     /* Lengden p� programnavnet */
    char prognavn [55];    /* Navn p� �nsket program. Dette er en string
                              p� formen:
                              " /C <navn> <parametre>\n"    */
    int  vent;
} transblokkstruct;

typedef struct {
    char tekst [31];
    int  meny;             /* Sann hvis valget er en undermeny */
    char menyfil  [13];    /* Navn p� evt. menyfil */
    char progdir  [51];    /* Programmets directory (hvis ikke meny) */
    char prognavn [51];    /* Startkommando uten /C (hvis ikke meny) */
} old_valgdatastruct;

typedef struct {
    char tekst [31];
    int  meny;             /* Sann hvis valget er en undermeny */
    char menyfil  [13];    /* Navn p� evt. menyfil */
    char progdir  [51];    /* Programmets directory (hvis ikke meny) */
    char prognavn [51];    /* Startkommando uten /C (hvis ikke meny) */
    int  vent;             /* Vent etter at programmet har avsluttet? */
} valgdatastruct;

typedef struct {
    char typetekst[30];    /* Vises hvis bruker pr�ver � TYPE *.MNY */
    char overskrift [77];
    unsigned rattr, vattr, oattr, tattr; /* Attributt p� ramme, valgtekst,
                                            overskrift og annen tekst. */
    old_valgdatastruct valg [ANTVALG];
} old_menydatastruct;

typedef struct {
    char typetekst[30];    /* Vises hvis bruker pr�ver � TYPE *.MNY */
    unsigned versjon;
    char overskrift [77];
    unsigned rattr, vattr, oattr, tattr; /* Attributt p� ramme, valgtekst,
                                            overskrift og annen tekst. */
    valgdatastruct valg [ANTVALG];
} menydatastruct;






void henttransblokk(void);
void sendtransblokk(void);
void settoppskjerm(void);
void feilmelding(char *s);
void klokke(void);
void hjelp(void);
void minneoversikt(void);
void finn_reelle_attributter(void);
void tommeny(void);
char * finn_nytt_navn(void);
void fjernblanke(char *s);
void skrivmeny(void);
void hentmeny(void);
void vismeny(void);
int  inplin(char *lin, int max, int attr1, int attr2);
int  ja_nei(int *std, int attr1, int attr2);
void redigervalg(void);
void fargevalg(void);
int  inneholder_undermeny(char *menynavn);
void slettvalg(void);
void overskrift(void);
void velg(void);
